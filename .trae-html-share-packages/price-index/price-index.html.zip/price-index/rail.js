// ===== 火运价格指数 —— 参考专业价格指数平台设计 =====
// 数据口径（与汽运价格指数一致）：
//   · 仅录入不含税价格，含税价 = 不含税 × 1.09 自动换算，禁止人工输入
//   · 价格指数：指数 = 当期价 / 基期价 × 100（基期取数据集最早一天 = 100）
//   · 依据来源：截图 / 报价单 / 合同扫描件等图片，自动压缩存储（每条记录最多 9 张）
//   · 历史记录可筛选查看，删除需确认；内置少量「示例」报价（可一键清除）
// 登录环节按需求省略：无登录页、无权限校验，运营方（管理员）视角直接进入
(function () {
  'use strict';

  var STORAGE_KEY = 'hz_rail_price_index';
  var VERSION = 'v1';              // 内置数据版本：v1 = 少量示例报价（可一键清除）
  var TAX_RATE = 1.09;             // 含税换算系数
  var MAX_EVIDENCES = 9;           // 每条记录依据来源图片上限
  var UPLOADER = '系统管理员';      // 无登录环节，上传人固定为运营方

  // ===== 工具 =====
  function $(sel) { return document.querySelector(sel); }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  var toastTimer = null;
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2400);
  }

  function uid(prefix) {
    return prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function fmtDate(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }

  function parseDate(s) { return new Date(s.replace(/-/g, '/')); }

  function taxOf(p) { return Math.round(p * TAX_RATE * 100) / 100; }

  function round2(x) { return Math.round(x * 100) / 100; }

  function avg(arr) {
    if (!arr.length) return 0;
    var s = 0;
    for (var i = 0; i < arr.length; i++) s += arr[i];
    return s / arr.length;
  }

  // 相对时间：X 分钟前 / X 小时前 / X 天前
  function timeAgo(uploadedAt) {
    var t = parseDate(uploadedAt.replace(' ', 'T'));
    if (isNaN(t.getTime())) return '';
    var diff = Date.now() - t.getTime();
    if (diff < 0) diff = 0;
    var m = Math.floor(diff / 60000);
    if (m < 1) return '刚刚';
    if (m < 60) return m + ' 分钟前';
    var h = Math.floor(m / 60);
    if (h < 24) return h + ' 小时前';
    var d = Math.floor(h / 24);
    if (d < 30) return d + ' 天前';
    return Math.floor(d / 30) + ' 个月前';
  }

  // ===== 内置数据 =====
  // 站点库（发站 = 港口铁路站；到站 = 目的站 / 城市）
  var SEED_STATIONS = {
    hot: ['黄骅港站', '武安'],
    ports: ['黄骅港站', '天津港站', '曹妃甸港站'],
    dests: ['武安', '邢台南站', '康城站', '涉县']
  };

  // 货物种类库
  var SEED_GOODS = {
    hot: ['铁矿石'],
    all: ['铁矿石', '钢坯', '焦炭']
  };

  // 示例报价（少量写死数据，带 demo 标记，可在「数据管理」一键清除；
  // 日期 / 价格均为手写固定值，非随机生成）
  var SEED_RECORDS = [
    { id: 'rl-demo-01', dataDate: '2026-10-13', goods: '铁矿石', from: '黄骅港站', to: '武安', price: 51.80, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-13 15:05' },
    { id: 'rl-demo-02', dataDate: '2026-10-14', goods: '铁矿石', from: '黄骅港站', to: '邢台南站', price: 45.00, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-14 15:12' },
    { id: 'rl-demo-03', dataDate: '2026-10-15', goods: '钢坯', from: '天津港站', to: '武安', price: 60.50, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-15 15:08' },
    { id: 'rl-demo-04', dataDate: '2026-10-16', goods: '铁矿石', from: '黄骅港站', to: '武安', price: 51.80, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-16 15:03' },
    { id: 'rl-demo-05', dataDate: '2026-10-18', goods: '铁矿石', from: '黄骅港站', to: '邢台南站', price: 45.20, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-18 15:16' },
    { id: 'rl-demo-06', dataDate: '2026-10-20', goods: '铁矿石', from: '黄骅港站', to: '武安', price: 52.10, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-20 15:09' },
    { id: 'rl-demo-07', dataDate: '2026-10-21', goods: '钢坯', from: '天津港站', to: '武安', price: 60.00, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-21 15:14' },
    { id: 'rl-demo-08', dataDate: '2026-10-23', goods: '铁矿石', from: '黄骅港站', to: '邢台南站', price: 45.00, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-23 15:07' },
    { id: 'rl-demo-09', dataDate: '2026-10-24', goods: '铁矿石', from: '黄骅港站', to: '武安', price: 52.35, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-24 15:11' },
    { id: 'rl-demo-10', dataDate: '2026-10-25', goods: '钢坯', from: '天津港站', to: '武安', price: 60.40, remark: '', evidences: [], demo: true, uploader: '系统管理员', uploadedAt: '2026-10-25 15:06' }
  ];

  function buildSeed() {
    return {
      __version: VERSION,
      stations: JSON.parse(JSON.stringify(SEED_STATIONS)),
      goods: JSON.parse(JSON.stringify(SEED_GOODS)),
      records: JSON.parse(JSON.stringify(SEED_RECORDS))
    };
  }

  // ===== 数据读写（localStorage） =====
  var db = null;

  function loadDB() {
    if (db) return db;
    try {
      var v = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (v && v.__version === VERSION && v.stations && v.goods && Array.isArray(v.records)) {
        db = v;
        return db;
      }
    } catch (e) { /* 解析失败则重建种子 */ }
    db = buildSeed();
    persist();
    return db;
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    } catch (e) {
      toast('本地存储空间不足，最新数据可能未完整保存');
    }
  }

  // ===== 派生数据 =====
  function allStations() {
    return db.stations.hot.concat(db.stations.ports, db.stations.dests);
  }

  function allGoodsOptions() {
    var set = {};
    db.goods.hot.concat(db.goods.all).forEach(function (g) { if (g) set[g] = true; });
    return Object.keys(set);
  }

  // 线路列表（由报价记录派生）：[{ key, from, to, count }]
  function deriveRoutes() {
    var map = {};
    db.records.forEach(function (r) {
      var key = r.from + '|' + r.to;
      if (!map[key]) map[key] = { key: key, from: r.from, to: r.to, count: 0 };
      map[key].count++;
    });
    return Object.keys(map).map(function (k) { return map[k]; });
  }

  // 基期值：数据集最早一天的均价（全部记录口径 / 指定记录集口径）
  function baseValue(recs) {
    var sorted = recs.slice().sort(function (a, b) { return a.dataDate.localeCompare(b.dataDate); });
    if (!sorted.length) return null;
    var firstDay = sorted[0].dataDate;
    return round2(avg(sorted.filter(function (r) { return r.dataDate === firstDay; })
      .map(function (r) { return r.price; })));
  }

  function baseLabel(recs) {
    var sorted = recs.slice().sort(function (a, b) { return a.dataDate.localeCompare(b.dataDate); });
    return sorted.length ? sorted[0].dataDate : '—';
  }

  // ===== 页面状态 =====
  var state = {
    routeKey: '',        // 走势图选中线路（'' = 全部线路综合）
    range: 'all',        // 30 / 90 / all
    mode: 'price',       // price / index
    evidences: [],       // 录入表单待上传依据来源（dataURL 数组）
    gallery: { list: [], idx: 0 },
    confirm: null
  };

  // 按线路过滤记录
  function recsOfRoute(routeKey) {
    if (!routeKey) return db.records;
    return db.records.filter(function (r) { return r.from + '|' + r.to === routeKey; });
  }

  // 按数据日期分组求均价序列：[{ date, pre, tax, idx, uploader, uploadedAt }]
  function daySeries(recs) {
    if (!recs.length) return { series: [], base: null };
    var base = baseValue(recs);
    var byDay = {};
    recs.forEach(function (r) {
      if (!byDay[r.dataDate]) byDay[r.dataDate] = { prices: [], rec: r };
      byDay[r.dataDate].prices.push(r.price);
      if (r.uploadedAt > byDay[r.dataDate].rec.uploadedAt) byDay[r.dataDate].rec = r;
    });
    var series = Object.keys(byDay).sort().map(function (d) {
      var g = byDay[d];
      var pre = round2(avg(g.prices));
      return {
        date: d,
        pre: pre,
        tax: taxOf(pre),
        idx: base ? round2(pre / base * 100) : null,
        uploader: g.rec.uploader,
        uploadedAt: g.rec.uploadedAt,
        rec: g.rec
      };
    });
    return { series: series, base: base };
  }

  // ===== 指数行情区 =====
  function chgHTML(diff, pct) {
    var cls = diff > 0 ? 'up' : (diff < 0 ? 'down' : 'flat');
    var arrow = diff > 0 ? '▲' : (diff < 0 ? '▼' : '—');
    var text = diff === 0 ? '持平' : arrow + ' ' + Math.abs(diff).toFixed(2) + '（' + (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%）';
    return '<span class="chg ' + cls + '">' + text + '</span>';
  }

  function renderHero() {
    var idxValue = $('#idxValue');
    var idxChg = $('#idxChg');
    var idxMeta = $('#idxMeta');

    if (!db.records.length) {
      idxValue.textContent = '—';
      idxChg.innerHTML = '';
      idxMeta.textContent = '暂无数据，点击右上角「新增报价」录入';
      return;
    }

    var ds = daySeries(db.records);
    var series = ds.series;
    var latest = series[series.length - 1];
    var prev = series.length > 1 ? series[series.length - 2] : null;

    idxValue.textContent = latest.idx.toFixed(2);
    if (prev) {
      var diff = round2(latest.idx - prev.idx);
      var pct = prev.idx ? diff / prev.idx * 100 : 0;
      idxChg.innerHTML = chgHTML(diff, pct);
    } else {
      idxChg.innerHTML = '<span class="chg flat">基期日</span>';
    }
    idxMeta.textContent = '基期 ' + baseLabel(db.records) + ' = 100 · 最新数据日期 ' + latest.date;
  }

  function renderRouteCards() {
    var box = $('#routeCards');
    var routes = deriveRoutes();

    if (!routes.length) {
      box.innerHTML = '<div class="rl-empty" style="grid-column:1/-1;">暂无线路行情，点击右上角「新增报价」录入</div>';
      return;
    }

    box.innerHTML = routes.map(function (rt) {
      var ds = daySeries(recsOfRoute(rt.key));
      var series = ds.series;
      var latest = series[series.length - 1];
      var prev = series.length > 1 ? series[series.length - 2] : null;
      var chg;
      if (prev) {
        var diff = round2(latest.pre - prev.pre);
        var pct = prev.pre ? diff / prev.pre * 100 : 0;
        chg = chgHTML(diff, pct);
      } else {
        chg = '<span class="chg flat">首条</span>';
      }
      var active = state.routeKey === rt.key ? ' active' : '';
      return '<div class="rl-route-card' + active + '" data-route="' + esc(rt.key) + '">' +
        '<div class="rl-route-name">' + esc(rt.from + ' → ' + rt.to) + '</div>' +
        '<div class="rl-route-price">' + latest.pre.toFixed(2) + '<small>元/吨</small></div>' +
        '<div class="rl-route-foot"><span>' + chg + '</span><span>' + esc(latest.date) + '</span></div>' +
        '</div>';
    }).join('');

    box.querySelectorAll('.rl-route-card').forEach(function (card) {
      card.addEventListener('click', function () {
        state.routeKey = card.dataset.route === state.routeKey ? '' : card.dataset.route;
        renderChips();
        renderRouteCards();
        renderChart();
      });
    });
  }

  // ===== 线路 chips =====
  function renderChips() {
    var box = $('#routeChips');
    var routes = deriveRoutes();
    var chips = ['<button class="rl-chip' + (state.routeKey === '' ? ' active' : '') + '" data-route="" type="button">全部线路</button>'];
    routes.forEach(function (rt) {
      chips.push('<button class="rl-chip' + (state.routeKey === rt.key ? ' active' : '') + '" data-route="' + esc(rt.key) + '" type="button">' +
        esc(rt.from + ' → ' + rt.to) + '</button>');
    });
    box.innerHTML = chips.join('');

    box.querySelectorAll('.rl-chip').forEach(function (chip) {
      chip.addEventListener('click', function () {
        state.routeKey = chip.dataset.route;
        renderChips();
        renderRouteCards();
        renderChart();
      });
    });
  }

  // ===== 走势图 =====
  var chartGeom = null;

  function renderChart() {
    var svg = $('#trendChart');
    var tip = $('#chartTip');
    if (!svg) return;
    tip.style.display = 'none';

    var isIdx = state.mode === 'index';
    $('#legendRow').querySelectorAll('.lg-item').forEach(function (el) {
      el.style.display = isIdx ? (el.classList.contains('lg-idx-only') ? '' : 'none')
                              : (el.classList.contains('lg-idx-only') ? 'none' : '');
    });

    var recs = recsOfRoute(state.routeKey);
    var ds = daySeries(recs);
    var series = ds.series;

    // 时间范围：以最新数据日期为终点
    if (series.length && (state.range === '30' || state.range === '90')) {
      var latestDate = series[series.length - 1].date;
      var cutoff = fmtDate(new Date(parseDate(latestDate).getTime() - (Number(state.range) - 1) * 86400000));
      series = series.filter(function (p) { return p.date >= cutoff; });
    }

    if (!series.length) {
      svg.innerHTML = '<text class="chart-empty" x="500" y="170" text-anchor="middle">当前筛选范围暂无报价数据</text>';
      chartGeom = null;
      return;
    }

    var W = 1000, H = 340;
    var PAD_L = 58, PAD_R = 26, PAD_T = 26, PAD_B = 40;
    var innerW = W - PAD_L - PAD_R;
    var innerH = H - PAD_T - PAD_B;

    // 时间定位：数据首尾日期映射到绘图区
    var t0 = parseDate(series[0].date).getTime();
    var t1 = parseDate(series[series.length - 1].date).getTime();
    if (t1 === t0) t1 = t0 + 86400000;
    function xAt(date) {
      return PAD_L + (parseDate(date).getTime() - t0) / (t1 - t0) * innerW;
    }

    // Y 轴：4 等分，上下留 8% 余量
    function valOf(p) { return isIdx ? p.idx : (state.routeKey ? p.pre : p.pre); }
    var vals = series.map(valOf);
    var vMin = Math.min.apply(null, vals);
    var vMax = Math.max.apply(null, vals);
    var span = (vMax - vMin) || (vMax || 1) * 0.1;
    var yMin = vMin - span * 0.08;
    var yMax = vMax + span * 0.08;
    function yAt(v) { return PAD_T + (1 - (v - yMin) / (yMax - yMin)) * innerH; }

    // 网格 + Y 轴标注
    var SEG = 4;
    var parts = [];
    for (var g = 0; g <= SEG; g++) {
      var gy = PAD_T + innerH * g / SEG;
      var gv = yMax - (yMax - yMin) * g / SEG;
      parts.push('<line class="trend-grid" x1="' + PAD_L + '" y1="' + gy.toFixed(1) + '" x2="' + (W - PAD_R) + '" y2="' + gy.toFixed(1) + '"/>');
      parts.push('<text class="trend-label" x="' + (PAD_L - 8) + '" y="' + (gy + 4).toFixed(1) + '" text-anchor="end">' + gv.toFixed(isIdx ? 1 : 2) + '</text>');
    }

    // X 轴日期标注（稀疏：最多 8 个）
    var MAX_LB = 8;
    var step = Math.max(1, Math.ceil(series.length / MAX_LB));
    series.forEach(function (p, i) {
      if (i % step !== 0 && i !== series.length - 1) return;
      var lb = p.date.slice(5);
      parts.push('<text class="trend-label" x="' + xAt(p.date).toFixed(1) + '" y="' + (H - 12) + '" text-anchor="middle">' + esc(lb) + '</text>');
    });

    // 渐变面积（仅价格模式的线路视图）
    if (!isIdx && state.routeKey) {
      parts.push('<defs><linearGradient id="rlAreaGrad" x1="0" y1="0" x2="0" y2="1">' +
        '<stop offset="0%" stop-color="#2E6BE6" stop-opacity="0.18"/>' +
        '<stop offset="100%" stop-color="#2E6BE6" stop-opacity="0"/></linearGradient></defs>');
      var area = 'M ' + xAt(series[0].date).toFixed(1) + ' ' + (PAD_T + innerH).toFixed(1);
      series.forEach(function (p) { area += ' L ' + xAt(p.date).toFixed(1) + ' ' + yAt(p.pre).toFixed(1); });
      area += ' L ' + xAt(series[series.length - 1].date).toFixed(1) + ' ' + (PAD_T + innerH).toFixed(1) + ' Z';
      parts.push('<path class="trend-area" d="' + area + '"/>');
    }

    // 折线
    function linePath(key) {
      var d = '';
      series.forEach(function (p, i) {
        d += (i ? ' L ' : 'M ') + xAt(p.date).toFixed(1) + ' ' + yAt(p[key]).toFixed(1);
      });
      return d;
    }
    if (isIdx) {
      parts.push('<path class="trend-line-idx" d="' + linePath('idx') + '"/>');
      var last = series[series.length - 1];
      parts.push('<circle class="trend-dot" cx="' + xAt(last.date).toFixed(1) + '" cy="' + yAt(last.idx).toFixed(1) + '" r="4"/>');
    } else {
      parts.push('<path class="trend-line-pre" d="' + linePath('pre') + '"/>');
      parts.push('<path class="trend-line-tax" d="' + linePath('tax') + '"/>');
      var lastP = series[series.length - 1];
      parts.push('<circle class="trend-dot" cx="' + xAt(lastP.date).toFixed(1) + '" cy="' + yAt(lastP.pre).toFixed(1) + '" r="4"/>');
    }

    parts.push('<line id="rlCross" class="trend-crosshair" y1="' + PAD_T + '" y2="' + (PAD_T + innerH) + '" visibility="hidden"/>');
    svg.innerHTML = parts.join('');

    chartGeom = {
      series: series, xAt: xAt, yAt: yAt, isIdx: isIdx,
      scale: 1000, padT: PAD_T
    };
  }

  function bindChartHover() {
    var wrap = $('#trendChart').parentNode;
    var svg = $('#trendChart');
    var tip = $('#chartTip');

    wrap.addEventListener('mousemove', function (ev) {
      if (!chartGeom) return;
      var rect = wrap.getBoundingClientRect();
      var scale = 1000 / rect.width;
      var mx = (ev.clientX - rect.left) * scale;

      var s = chartGeom.series, g = chartGeom;
      var nearest = null, nd = Infinity;
      s.forEach(function (p) {
        var d = Math.abs(g.xAt(p.date) - mx);
        if (d < nd) { nd = d; nearest = p; }
      });
      if (!nearest) return;

      var px = g.xAt(nearest.date);
      var py = g.yAt(chartGeom.isIdx ? nearest.idx : nearest.pre);

      var cross = svg.querySelector('#rlCross');
      if (cross) {
        cross.setAttribute('x1', px.toFixed(1));
        cross.setAttribute('x2', px.toFixed(1));
        cross.setAttribute('visibility', 'visible');
      }

      var rows;
      if (chartGeom.isIdx) {
        rows = '<div class="tip-row"><i class="lg-dot lg-idx"></i><span>指数</span><b>' + nearest.idx.toFixed(2) + '</b></div>';
      } else {
        rows =
          '<div class="tip-row"><i class="lg-dot lg-pre"></i><span>不含税价</span><b>' + nearest.pre.toFixed(2) + ' 元/吨</b></div>' +
          '<div class="tip-row"><i class="lg-dot lg-tax"></i><span>含税价</span><b>' + nearest.tax.toFixed(2) + ' 元/吨</b></div>' +
          '<div class="tip-row"><i class="lg-dot lg-idx"></i><span>指数</span><b>' + nearest.idx.toFixed(2) + '</b></div>';
      }

      tip.innerHTML = '<div class="tip-date">' + esc(nearest.date) + '</div>' + rows +
        '<div class="tip-uploader">上传人：' + esc(nearest.uploader) + ' · ' + esc(nearest.uploadedAt) + '</div>';
      tip.style.display = 'block';

      var wrapW = rect.width;
      var tipW = tip.offsetWidth || 200;
      var left = px / scale - tipW - 14;
      if (left < 6) left = px / scale + 14;
      if (left + tipW > wrapW - 6) left = wrapW - tipW - 6;
      var top = Math.max(4, py * (rect.height / 340) - 40);
      tip.style.left = left + 'px';
      tip.style.top = top + 'px';
    });

    wrap.addEventListener('mouseleave', function () {
      tip.style.display = 'none';
      var cross = svg.querySelector('#rlCross');
      if (cross) cross.setAttribute('visibility', 'hidden');
    });
  }

  // ===== 最新行情（按线路，取该线路最新一天报价） =====
  function renderLatest() {
    var body = $('#latestBody');
    var routes = deriveRoutes();
    $('#latestCount').textContent = routes.length ? routes.length + ' 条线路' : '';

    if (!routes.length) {
      body.innerHTML = '<tr><td colspan="8" class="rl-empty">暂无行情数据</td></tr>';
      return;
    }

    body.innerHTML = routes.map(function (rt) {
      var recs = recsOfRoute(rt.key);
      var ds = daySeries(recs);
      var series = ds.series;
      var latest = series[series.length - 1];
      var prev = series.length > 1 ? series[series.length - 2] : null;
      var chg;
      if (prev) {
        var diff = round2(latest.pre - prev.pre);
        var pct = prev.pre ? diff / prev.pre * 100 : 0;
        chg = chgHTML(diff, pct);
      } else {
        chg = '<span class="chg flat">首条</span>';
      }
      var evBtn = latest.rec.evidences && latest.rec.evidences.length
        ? '<button class="ev-link" data-ev="' + esc(latest.rec.id) + '" type="button">🔗 ' + latest.rec.evidences.length + ' 张</button>'
        : '<span class="dim">—</span>';
      var demoTag = latest.rec.demo ? '<span class="demo-tag">示例</span>' : '';
      return '<tr>' +
        '<td>' + esc(rt.from + ' → ' + rt.to) + '</td>' +
        '<td>' + esc(latest.rec.goods) + '</td>' +
        '<td class="num">' + latest.pre.toFixed(2) + '</td>' +
        '<td class="num">' + latest.tax.toFixed(2) + '</td>' +
        '<td>' + chg + '</td>' +
        '<td class="dim">' + esc(latest.date) + '</td>' +
        '<td>' + evBtn + '</td>' +
        '<td class="dim">' + esc(latest.rec.uploadedAt) + demoTag + '</td>' +
        '</tr>';
    }).join('');

    bindEvLinks(body);
  }

  // 凭证按钮统一绑定（事件委托备用：直接绑定）
  function bindEvLinks(box) {
    box.querySelectorAll('.ev-link').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var rec = db.records.find(function (x) { return x.id === btn.dataset.ev; });
        if (rec && rec.evidences && rec.evidences.length) openGallery(rec.evidences, 0);
      });
    });
  }

  // ===== 历史记录 =====
  function renderHistoryFilterOptions() {
    var routeSel = $('#hisRoute');
    var goodsSel = $('#hisGoods');
    var keepRoute = routeSel.value;
    var keepGoods = goodsSel.value;

    var routes = deriveRoutes();
    routeSel.innerHTML = '<option value="">全部线路</option>' + routes.map(function (rt) {
      return '<option value="' + esc(rt.key) + '">' + esc(rt.from + ' → ' + rt.to) + '</option>';
    }).join('');
    routeSel.value = keepRoute || '';
    if (routeSel.selectedIndex === -1) routeSel.value = '';

    goodsSel.innerHTML = '<option value="">全部货物</option>' + allGoodsOptions().map(function (g) {
      return '<option value="' + esc(g) + '">' + esc(g) + '</option>';
    }).join('');
    goodsSel.value = keepGoods || '';
    if (goodsSel.selectedIndex === -1) goodsSel.value = '';
  }

  function renderHistory() {
    var fRoute = $('#hisRoute').value;
    var fGoods = $('#hisGoods').value;
    var dStart = $('#hisFrom').value;
    var dEnd = $('#hisTo').value;
    var kw = $('#hisKeyword').value.trim();

    var list = db.records.filter(function (r) {
      if (fRoute && r.from + '|' + r.to !== fRoute) return false;
      if (fGoods && r.goods !== fGoods) return false;
      if (dStart && r.dataDate < dStart) return false;
      if (dEnd && r.dataDate > dEnd) return false;
      if (kw && (r.from + r.to + r.goods + r.remark).indexOf(kw) === -1) return false;
      return true;
    }).sort(function (a, b) {
      return b.dataDate.localeCompare(a.dataDate) || b.uploadedAt.localeCompare(a.uploadedAt);
    });

    $('#hisCount').textContent = '共 ' + list.length + ' 条';

    if (!list.length) {
      $('#hisBody').innerHTML = '<tr><td colspan="10" class="rl-empty">当前筛选条件下暂无记录</td></tr>';
      return;
    }

    $('#hisBody').innerHTML = list.map(function (r) {
      var evBtn = r.evidences && r.evidences.length
        ? '<button class="ev-link" data-ev="' + esc(r.id) + '" type="button">🔗 ' + r.evidences.length + ' 张</button>'
        : '<span class="dim">—</span>';
      var demoTag = r.demo ? '<span class="demo-tag">示例</span>' : '';
      return '<tr>' +
        '<td>' + esc(r.dataDate) + '</td>' +
        '<td>' + esc(r.from + ' → ' + r.to) + '</td>' +
        '<td>' + esc(r.goods) + demoTag + '</td>' +
        '<td class="num">' + r.price.toFixed(2) + '</td>' +
        '<td class="num">' + taxOf(r.price).toFixed(2) + '</td>' +
        '<td>' + evBtn + '</td>' +
        '<td class="dim" style="max-width:180px;overflow:hidden;text-overflow:ellipsis;">' + esc(r.remark || '—') + '</td>' +
        '<td>' + esc(r.uploader) + '</td>' +
        '<td class="dim">' + esc(r.uploadedAt) + '</td>' +
        '<td><button class="del-btn" data-del="' + esc(r.id) + '" type="button" title="删除">✕</button></td>' +
        '</tr>';
    }).join('');

    bindEvLinks($('#hisBody'));
    $('#hisBody').querySelectorAll('[data-del]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var rec = db.records.find(function (x) { return x.id === btn.dataset.del; });
        if (!rec) return;
        openConfirm('删除该条上传记录？',
          esc(rec.dataDate) + ' · ' + esc(rec.from + '→' + rec.to) + ' · ' + esc(rec.goods) +
          ' · ' + rec.price.toFixed(2) + ' 元/吨（上传人：' + esc(rec.uploader) + '）',
          function () {
            db.records = db.records.filter(function (x) { return x.id !== rec.id; });
            persist();
            renderAll();
            toast('记录已删除');
          });
      });
    });
  }

  function refreshAfterDataChange() {
    renderHero();
    renderRouteCards();
    renderChips();
    renderChart();
    renderLatest();
    renderHistoryFilterOptions();
    renderHistory();
  }

  function renderAll() {
    refreshAfterDataChange();
  }

  // ===== 弹窗通用 =====
  function openMask(id) { $(id).classList.add('show'); }
  function closeMask(id) { $(id).classList.remove('show'); }

  // ===== 新增报价弹窗 =====
  function renderEntryOptions() {
    $('#goodsList').innerHTML = allGoodsOptions().map(function (g) {
      return '<option value="' + esc(g) + '"></option>';
    }).join('');
    $('#fromList').innerHTML = allStations().map(function (s) {
      return '<option value="' + esc(s) + '"></option>';
    }).join('');
    $('#toList').innerHTML = allStations().map(function (s) {
      return '<option value="' + esc(s) + '"></option>';
    }).join('');
  }

  function resetEntryForm() {
    var now = new Date();
    $('#entryDate').value = fmtDate(now);
    $('#entryGoods').value = '';
    $('#entryFrom').value = '';
    $('#entryTo').value = '';
    $('#entryPrice').value = '';
    $('#entryTax').value = '';
    $('#entryRemark').value = '';
    state.evidences = [];
    renderThumbs();
  }

  function renderThumbs() {
    $('#entryThumbs').innerHTML = state.evidences.map(function (src, i) {
      return '<div class="rl-thumb">' +
        '<img src="' + src + '" data-thumb="' + i + '" alt="依据来源缩略图" />' +
        '<button class="thumb-del" data-del="' + i + '" type="button">✕</button></div>';
    }).join('');
    $('#entryThumbs').querySelectorAll('img').forEach(function (img) {
      img.addEventListener('click', function () { openGallery(state.evidences, Number(img.dataset.thumb)); });
    });
    $('#entryThumbs').querySelectorAll('[data-del]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        state.evidences.splice(Number(btn.dataset.del), 1);
        renderThumbs();
      });
    });
  }

  // 图片压缩（≤10M jpg/png，最长边压至 1400px JPEG）
  function compressImage(file, cb) {
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        var scale = Math.min(1, 1400 / Math.max(img.width, img.height));
        var canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        cb(canvas.toDataURL('image/jpeg', 0.72));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  }

  function handleEntryFiles(files) {
    if (!files || !files.length) return;
    var list = Array.prototype.slice.call(files);
    var accepted = [];
    for (var i = 0; i < list.length; i++) {
      var f = list[i];
      if (!/^image\/(jpeg|png)$/.test(f.type)) { toast('「' + f.name + '」不是 jpg / png 图片，已跳过'); continue; }
      if (f.size > 10 * 1024 * 1024) { toast('「' + f.name + '」超过 10M，已跳过'); continue; }
      accepted.push(f);
    }
    accepted.forEach(function (f) {
      if (state.evidences.length >= MAX_EVIDENCES) { toast('依据来源最多 ' + MAX_EVIDENCES + ' 张'); return; }
      compressImage(f, function (dataUrl) {
        if (state.evidences.length >= MAX_EVIDENCES) { toast('依据来源最多 ' + MAX_EVIDENCES + ' 张'); return; }
        state.evidences.push(dataUrl);
        renderThumbs();
      });
    });
  }

  function saveRecord() {
    var dataDate = $('#entryDate').value;
    var goods = $('#entryGoods').value.trim();
    var from = $('#entryFrom').value.trim();
    var to = $('#entryTo').value.trim();
    var price = parseFloat($('#entryPrice').value);
    var remark = $('#entryRemark').value.trim();

    if (!dataDate) { toast('请选择数据日期'); return; }
    if (!goods) { toast('请填写货物种类'); return; }
    if (!from || !to) { toast('请选择或填写完整运输线路（发站 / 到站）'); return; }
    if (from === to) { toast('发站与到站不能相同'); return; }
    if (!(price > 0)) { toast('不含税价格必须为大于 0 的数字'); return; }

    var now = new Date();
    db.records.push({
      id: uid('rl'),
      dataDate: dataDate,
      goods: goods,
      from: from,
      to: to,
      price: round2(price),
      remark: remark,
      evidences: state.evidences.slice(),
      demo: false,
      uploader: UPLOADER,
      uploadedAt: fmtDate(now) + ' ' + pad2(now.getHours()) + ':' + pad2(now.getMinutes())
    });
    persist();
    closeMask('#entryMask');
    refreshAfterDataChange();
    toast('报价已保存');
  }

  // ===== 数据管理弹窗 =====
  function renderBase() {
    var groups = [
      { key: 'ports', name: '港口站（发站）' },
      { key: 'dests', name: '目的站（到站）' }
    ];
    $('#stationGroups').innerHTML = groups.map(function (g) {
      var list = (db.stations[g.key] || []);
      var tags = list.length ? list.map(function (s) {
        var used = db.records.some(function (r) { return r.from === s || r.to === s; });
        return '<span class="rl-tag">' + esc(s) +
          '<button data-st="' + esc(s) + '" data-group="' + g.key + '" type="button" title="' +
          (used ? '该站点已被报价记录引用，不可删除' : '删除') + '">' + (used ? '·' : '✕') + '</button></span>';
      }).join('') : '<span class="rl-empty" style="padding:4px 0;">暂无站点</span>';
      return '<div class="rl-base-group"><div class="rl-base-group-name">' + g.name + '</div>' +
        '<div class="rl-chipset">' + tags + '</div></div>';
    }).join('');

    $('#stationGroups').querySelectorAll('[data-st]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var s = btn.dataset.st;
        var used = db.records.some(function (r) { return r.from === s || r.to === s; });
        if (used) { toast('该站点已被报价记录引用，不可删除'); return; }
        openConfirm('删除站点「' + esc(s) + '」？', '', function () {
          db.stations[btn.dataset.group] = db.stations[btn.dataset.group].filter(function (x) { return x !== s; });
          db.stations.hot = db.stations.hot.filter(function (x) { return x !== s; });
          persist();
          renderBase();
          renderEntryOptions();
          toast('站点已删除');
        });
      });
    });

    $('#goodsChips').innerHTML = allGoodsOptions().length ? allGoodsOptions().map(function (g) {
      var used = db.records.some(function (r) { return r.goods === g; });
      return '<span class="rl-tag">' + esc(g) +
        '<button data-goods="' + esc(g) + '" type="button" title="' +
        (used ? '该货物已被报价记录引用，不可删除' : '删除') + '">' + (used ? '·' : '✕') + '</button></span>';
    }).join('') : '<span class="rl-empty" style="padding:4px 0;">暂无货物种类</span>';

    $('#goodsChips').querySelectorAll('[data-goods]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var g = btn.dataset.goods;
        var used = db.records.some(function (r) { return r.goods === g; });
        if (used) { toast('该货物种类已被报价记录引用，不可删除'); return; }
        openConfirm('删除货物种类「' + esc(g) + '」？', '', function () {
          db.goods.all = db.goods.all.filter(function (x) { return x !== g; });
          db.goods.hot = db.goods.hot.filter(function (x) { return x !== g; });
          persist();
          renderBase();
          renderEntryOptions();
          renderHistoryFilterOptions();
          toast('货物种类已删除');
        });
      });
    });

    var demoN = db.records.filter(function (r) { return r.demo; }).length;
    $('#demoCount').textContent = demoN ? '当前有 ' + demoN + ' 条示例记录' : '暂无示例记录';
  }

  function clearDemo() {
    var demoN = db.records.filter(function (r) { return r.demo; }).length;
    if (!demoN) { toast('暂无示例记录'); return; }
    openConfirm('清除全部示例数据？', '共 ' + demoN + ' 条示例记录将被删除，真实录入数据不受影响。', function () {
      db.records = db.records.filter(function (r) { return !r.demo; });
      persist();
      renderBase();
      refreshAfterDataChange();
      toast('示例数据已清除');
    });
  }

  // ===== 确认 / 画廊 =====
  function openConfirm(question, detailHtml, cb) {
    $('#confirmTitle').textContent = '删除确认';
    $('#confirmText').innerHTML = esc(question) +
      (detailHtml ? '<span class="rl-confirm-detail">' + detailHtml + '</span>' : '');
    state.confirm = cb;
    openMask('#confirmMask');
  }

  function openGallery(list, idx) {
    if (!list || !list.length) return;
    state.gallery = { list: list, idx: idx || 0 };
    showGallery();
    openMask('#gallery');
    $('#gallery').classList.add('show');
  }

  function showGallery() {
    var g = state.gallery;
    $('#galleryImg').src = g.list[g.idx];
    $('#galleryCount').textContent = (g.idx + 1) + ' / ' + g.list.length;
    $('#galleryPrev').style.display = g.list.length > 1 ? '' : 'none';
    $('#galleryNext').style.display = g.list.length > 1 ? '' : 'none';
  }

  function galleryShift(d) {
    var g = state.gallery;
    if (!g.list.length) return;
    g.idx = (g.idx + d + g.list.length) % g.list.length;
    showGallery();
  }

  // ===== 导航高亮 =====
  function setActiveNav() {
    var navbar = document.getElementById('navbar');
    if (!navbar || !navbar.children.length) return;
    var sub = navbar.querySelector('.nav-sub-item[data-path="价格指数管理 / 火运价格指数"]');
    if (!sub) return;
    navbar.querySelectorAll('.nav-item.active, .nav-sub-item.active')
      .forEach(function (el) { el.classList.remove('active'); });
    sub.classList.add('active');
    var group = sub.closest('.nav-group');
    if (group) group.classList.add('open');
  }

  // ===== 事件绑定 =====
  function bindEvents() {
    $('#btnEntry').addEventListener('click', function () { openMask('#entryMask'); });
    $('#btnBase').addEventListener('click', function () { renderBase(); openMask('#baseMask'); });
    $('#entryClose').addEventListener('click', function () { closeMask('#entryMask'); });
    $('#baseClose').addEventListener('click', function () { closeMask('#baseMask'); });
    $('#btnResetEntry').addEventListener('click', function () { resetEntryForm(); toast('已清空'); });
    $('#btnSave').addEventListener('click', saveRecord);

    // 含税价自动换算
    $('#entryPrice').addEventListener('input', function () {
      var p = parseFloat(this.value);
      $('#entryTax').value = (p > 0) ? taxOf(p).toFixed(2) : '';
    });

    // 凭证上传
    $('#entryFiles').addEventListener('change', function () {
      handleEntryFiles(this.files);
      this.value = '';
    });

    // 走势图工具
    $('#rangeBtns').querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $('#rangeBtns').querySelectorAll('button').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        state.range = btn.dataset.range;
        renderChart();
      });
    });
    $('#modeBtns').querySelectorAll('button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $('#modeBtns').querySelectorAll('button').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        state.mode = btn.dataset.mode;
        renderChart();
      });
    });

    // 历史筛选
    ['#hisRoute', '#hisGoods', '#hisFrom', '#hisTo', '#hisKeyword'].forEach(function (sel) {
      $(sel).addEventListener('change', renderHistory);
      $(sel).addEventListener('input', renderHistory);
    });
    $('#btnHisReset').addEventListener('click', function () {
      $('#hisRoute').value = '';
      $('#hisGoods').value = '';
      $('#hisFrom').value = '';
      $('#hisTo').value = '';
      $('#hisKeyword').value = '';
      renderHistory();
    });

    // 数据管理
    $('#btnAddStation').addEventListener('click', function () {
      var name = $('#stAddInput').value.trim();
      if (!name) { toast('请输入站点名称'); return; }
      if (allStations().indexOf(name) !== -1) { toast('该站点已存在'); return; }
      db.stations[$('#stGroupSel').value].push(name);
      persist();
      $('#stAddInput').value = '';
      renderBase();
      renderEntryOptions();
      toast('站点已添加');
    });
    $('#btnAddGoods').addEventListener('click', function () {
      var name = $('#goodsAddInput').value.trim();
      if (!name) { toast('请输入货物种类'); return; }
      if (allGoodsOptions().indexOf(name) !== -1) { toast('该货物种类已存在'); return; }
      db.goods.all.push(name);
      persist();
      $('#goodsAddInput').value = '';
      renderBase();
      renderEntryOptions();
      renderHistoryFilterOptions();
      toast('货物种类已添加');
    });
    $('#btnClearDemo').addEventListener('click', clearDemo);

    // 确认弹窗
    $('#confirmClose').addEventListener('click', function () { closeMask('#confirmMask'); });
    $('#confirmCancel').addEventListener('click', function () { closeMask('#confirmMask'); });
    $('#confirmOk').addEventListener('click', function () {
      closeMask('#confirmMask');
      if (state.confirm) { var cb = state.confirm; state.confirm = null; cb(); }
    });

    // 画廊
    $('#galleryClose').addEventListener('click', function () { $('#gallery').classList.remove('show'); });
    $('#galleryPrev').addEventListener('click', function () { galleryShift(-1); });
    $('#galleryNext').addEventListener('click', function () { galleryShift(1); });

    // 点击遮罩关闭
    ['#entryMask', '#baseMask', '#confirmMask'].forEach(function (id) {
      $(id).addEventListener('click', function (ev) {
        if (ev.target === $(id)) closeMask(id);
      });
    });
    $('#gallery').addEventListener('click', function (ev) {
      if (ev.target === $('#gallery')) $('#gallery').classList.remove('show');
    });
  }

  // ===== 初始化 =====
  function init() {
    loadDB();
    renderEntryOptions();
    resetEntryForm();
    refreshAfterDataChange();
    bindEvents();
    bindChartHover();
    setActiveNav();
    document.addEventListener('navbar:loaded', setActiveNav);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
