// ===== 新建订单页交互逻辑（订单管理模块 · PRD F1-F6）=====
// 数据层：order-new-data.js（HZOrderNewData：登录主体/基础数据/校验/智能方案/组装）
//         flow-data.js（HZFlowData：订单落库/港口/运力/海运航次联动）
// 协作：common/hz-data.js（HZData 基础数据）、customers/data.js（BR-O11 客户库联动）、
//       business-data.js（订单台账同步，经 upsertOrder 自动触发）
(function () {
  'use strict';

  /* ==================== 导航高亮 ==================== */

  // 本页对应的导航路径（与 navbar.html 中 data-path 一致）
  const NAV_PATH = '订单管理';

  function setActiveNav() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;
    navbar.querySelectorAll('.active').forEach(el => el.classList.remove('active'));
    const item = navbar.querySelector(`[data-path="${NAV_PATH}"]`);
    if (item) item.classList.add('active');
    const group = item ? item.closest('.nav-group') : null;
    if (group) group.classList.add('open');
  }

  const navbar = document.getElementById('navbar');
  if (navbar && navbar.children.length) {
    setActiveNav();
  } else {
    document.addEventListener('navbar:loaded', setActiveNav, { once: true });
  }

  /* ==================== 依赖与元素 ==================== */

  const D = window.HZOrderNewData;
  const data = window.HZFlowData;
  const hz = window.HZData;
  const $ = id => document.getElementById(id);

  const els = {
    banner: $('subject-banner'),
    sumSubject: $('sum-subject'),
    sumCore: $('sum-core'),
    sumPlan: $('sum-plan'),
    subjectCompany: $('subject-company'),
    subjectContact: $('subject-contact'),
    subjectPhone: $('subject-phone'),
    mine: $('f-mine'), panelMine: $('panel-mine'),
    category: $('f-category'),
    cargoName: $('f-cargoName'), cargoQuality: $('f-cargoQuality'),
    tonnage: $('f-tonnage'), price: $('f-price'),
    port: $('f-port'), panelPort: $('panel-port'),
    arrivalAt: $('f-arrivalAt'), departAt: $('f-departAt'),
    wharfChips: $('wharf-chips'), wharfHint: $('wharf-hint'),
    vessel: $('f-vessel'),
    destStations: $('dest-stations'), destYards: $('dest-yards'), destSteels: $('dest-steels'),
    destPath: $('dest-path'), destClear: $('dest-clear'),
    planStatus: $('plan-status'), planGrid: $('plan-grid'), planFail: $('plan-fail'),
    planRetry: $('plan-retry'),
    vesselType: $('v-type'),
    btnSubmit: $('btn-submit'), btnReset: $('btn-reset'),
    successMask: $('success-mask'), successOrderId: $('success-order-id'),
    btnGoPort: $('btn-go-port'), btnGoDetail: $('btn-go-detail'),
    toast: $('toast'),
  };

  // 字段 → 输入元素映射（校验错误定位用；destination/subject 走区块滚动）
  const FIELD_INPUT = {
    mine: els.mine, cargoName: els.cargoName, cargoQuality: els.cargoQuality,
    tonnage: els.tonnage, price: els.price, port: els.port,
  };

  /* ==================== 页面状态 ==================== */

  const state = {
    subjectRes: null,          // 登录主体解析结果（F2/E1/TBD-01）
    hzMines: [],               // 矿山管理原始数据（品类映射用）
    mineOptions: [],           // 合并后的矿山选项 [{name, categories, grade}]
    portOptions: [],           // 合并后的港口选项 [string]
    wharfOptions: [],          // 码头选项 [string]
    customers: [],             // 客户库全量（BR-O11 状态联动）
    dest: { station: '', yard: '', steel: '', auto: false }, // 目的地级联状态
    wharfs: [],                // 已选码头（保持点选顺序）
    plansRes: null,            // 最近一次智能方案计算结果（运力预填用）
    submitting: false,         // E8 防重标志
    savedOrder: null,          // 提交成功后的订单（成功浮层跳转携带 id 用）
  };

  /* ==================== 通用提示与校验渲染 ==================== */

  let toastTimer = null;
  function toast(msg, type) {
    els.toast.textContent = msg;
    els.toast.classList.toggle('error', type === 'error');
    els.toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2200);
  }

  // 防 XSS：所有动态文本经 esc 后再进入 innerHTML
  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // 单字段错误渲染：hint 文案（err 红 / warn 橙 / ok 绿）+ 输入框红边
  function showHint(field, msg, level) {
    const hint = document.querySelector(`[data-hint="${field}"]`);
    if (!hint) return;
    hint.textContent = msg || '';
    hint.classList.remove('err', 'warn', 'ok');
    if (msg && level) hint.classList.add(level);
    const input = FIELD_INPUT[field];
    if (input) input.setAttribute('data-error', msg ? 'true' : 'false');
  }

  function clearHint(field) { showHint(field, '', ''); }

  /* ==================== 初始化：登录主体（F2 / E1 / TBD-01） ==================== */

  function initSubject() {
    state.subjectRes = D.getLoginSubject();
    if (!state.subjectRes.ok) {
      // E1：登录主体缺失，阻断提交（自然信息不可手填，保证主体归属准确）
      els.banner.hidden = false;
      els.banner.className = 'subject-banner danger';
      els.banner.textContent = state.subjectRes.error || D.MSG.subjectBlocked;
      els.sumSubject.textContent = '未获取';
      els.btnSubmit.disabled = true;
      return;
    }
    const s = state.subjectRes.subject;
    els.subjectCompany.value = s.company;
    els.subjectContact.value = s.contact || '—';
    els.subjectPhone.value = s.phone;
    els.sumSubject.textContent = s.company;
    if (state.subjectRes.degraded) {
      // TBD-01 降级提示：登录体系未接入，以平台运营方模拟主体填充
      els.banner.hidden = false;
      els.banner.className = 'subject-banner info';
      els.banner.textContent = '登录体系未接入，当前以平台运营方主体自动填充自然信息（接入后自动替换，不可手动修改）';
    }
  }

  /* ==================== 初始化：基础数据（F3 / TBD-02 / E7） ==================== */

  function initMineOptions() {
    try { state.hzMines = hz.list('mines') || []; } catch (e) { state.hzMines = []; }
    state.mineOptions = D.listMineOptions(state.hzMines);
  }

  function initPortOptions() {
    let ports = [], dictPorts = [];
    try { ports = hz.list('ports') || []; } catch (e) { ports = []; }
    try { dictPorts = hz.dict('dischargePorts') || []; } catch (e) { dictPorts = []; }
    state.portOptions = D.listPortOptions(ports, dictPorts);
    // E7：港口基础数据为空时提示联系运营维护（种子兜底后仍为空仅发生于覆盖键被清空的场景）
    if (!state.portOptions.length) {
      showHint('port', D.MSG.noBaseData, 'warn');
    }
  }

  function initWharfChips() {
    state.wharfOptions = D.listWharfOptions();
    els.wharfChips.innerHTML = '';
    if (!state.wharfOptions.length) {
      els.wharfHint.hidden = false;
      els.wharfHint.textContent = D.MSG.noBaseData;
      els.wharfHint.classList.add('warn');
      return;
    }
    state.wharfOptions.forEach(name => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'chip';
      chip.textContent = name;
      chip.addEventListener('click', () => {
        const idx = state.wharfs.indexOf(name);
        if (idx >= 0) { state.wharfs.splice(idx, 1); chip.classList.remove('on'); }
        else { state.wharfs.push(name); chip.classList.add('on'); }
        refreshCoreSummary();
      });
      els.wharfChips.appendChild(chip);
    });
  }

  function initVesselType() {
    els.vesselType.innerHTML = '<option value="">请选择船型类别</option>' +
      D.VESSEL_TYPES.map(t => `<option value="${esc(t)}">${esc(t)}</option>`).join('');
  }

  /* ==================== 搜索下拉（矿山 / 港口） ==================== */

  function setupSS(input, panel, opts) {
    function close() { panel.classList.remove('open'); }
    function render() {
      const q = input.value.trim();
      const all = opts.getOptions() || [];
      const items = all.filter(v => !q || v.indexOf(q) >= 0);
      panel.innerHTML = '';
      if (!items.length) {
        const empty = document.createElement('div');
        empty.className = 'ss-empty';
        empty.textContent = all.length ? '无匹配项' : (opts.emptyText || D.MSG.noBaseData);
        panel.appendChild(empty);
      } else {
        items.forEach(v => {
          const opt = document.createElement('div');
          opt.className = 'ss-option';
          opt.textContent = v;
          opt.addEventListener('mousedown', e => {
            e.preventDefault(); // 先于 input blur 触发，保证点选生效
            input.value = v;
            close();
            opts.onPick(v);
          });
          panel.appendChild(opt);
        });
      }
      panel.classList.add('open');
    }
    input.addEventListener('focus', render);
    input.addEventListener('input', render);
    input.addEventListener('blur', () => setTimeout(close, 120));
  }

  function initMineSS() {
    setupSS(els.mine, els.panelMine, {
      getOptions: () => state.mineOptions.map(m => m.name),
      onPick: onMinePick,
      emptyText: D.MSG.noBaseData,
    });
  }

  function onMinePick(name) {
    clearHint('mine');
    // A1/A3：品类自动带出（只读，不支持手选 TBD-05）；E2：无映射时提示
    const res = D.categoryOfMine(name, state.hzMines);
    if (res.ok) {
      els.category.value = res.value;
      showHint('category', '', '');
    } else {
      els.category.value = '';
      showHint('category', res.error || D.MSG.noBaseData, 'warn');
    }
    refreshCoreSummary();
    refreshPlans();
  }

  function initPortSS() {
    setupSS(els.port, els.panelPort, {
      getOptions: () => state.portOptions,
      onPick: name => {
        clearHint('port');
        refreshCoreSummary();
        refreshPlans();
      },
      emptyText: D.MSG.noBaseData,
    });
  }

  /* ==================== 目的地级联（G4 / A4 / A5 / BR-O11 / E5） ==================== */

  function renderDestStations() {
    const stations = D.listStations();
    els.destStations.innerHTML = '';
    if (!stations.length) {
      els.destStations.innerHTML = `<div class="dest-empty">${esc(D.MSG.noBaseData)}</div>`;
      return;
    }
    stations.forEach(st => {
      const opt = document.createElement('div');
      opt.className = 'dest-opt' + (state.dest.station === st ? ' on' : '');
      opt.textContent = st;
      opt.addEventListener('click', () => {
        state.dest = { station: st, yard: '', steel: '', auto: false };
        renderDest();
        refreshCoreSummary();
        refreshPlans();
      });
      els.destStations.appendChild(opt);
    });
  }

  function renderDestYards() {
    els.destYards.innerHTML = '';
    if (!state.dest.station) {
      els.destYards.innerHTML = '<div class="dest-empty">请先选择铁路站</div>';
      return;
    }
    const yards = D.listYards(state.dest.station);
    if (!yards.length) {
      els.destYards.innerHTML = `<div class="dest-empty">${esc(D.MSG.noBaseData)}</div>`;
      return;
    }
    yards.forEach(yd => {
      const opt = document.createElement('div');
      opt.className = 'dest-opt' + (state.dest.yard === yd ? ' on' : '');
      opt.textContent = yd;
      opt.addEventListener('click', () => {
        state.dest.yard = yd;
        state.dest.steel = '';
        // A5 反向关联：未显式选择铁路站时，由堆场带出所属站点并标注「自动带出」
        // （用户已显式选站的场景不标注，保持用户选择口径）
        const st = D.resolveStationOfYard(yd);
        if (st && !state.dest.station) {
          state.dest.station = st;
          state.dest.auto = true;
        } else if (st && st !== state.dest.station) {
          state.dest.station = st; // 堆场归属站点与显式所选不一致时，以堆场归属为准
        }
        renderDest();
        clearHint('destination');
        refreshCoreSummary();
        refreshPlans();
      });
      els.destYards.appendChild(opt);
    });
  }

  function renderDestSteels() {
    els.destSteels.innerHTML = '';
    if (!state.dest.yard) {
      els.destSteels.innerHTML = '<div class="dest-empty">请先选择堆场</div>';
      return;
    }
    // BR-O11：目录钢厂与客户库联动，非「正常」状态置灰不可选
    let all = [], allowed = [];
    const entry = D.getDestCatalog().find(s => s.station === state.dest.station);
    const yardEntry = entry ? entry.yards.find(y => y.yard === state.dest.yard) : null;
    all = yardEntry ? yardEntry.steels : [];
    allowed = D.listSteels(state.dest.yard, state.customers);
    if (!all.length) {
      els.destSteels.innerHTML = `<div class="dest-empty">${esc(D.MSG.noBaseData)}</div>`;
      return;
    }
    all.forEach(name => {
      const disabled = allowed.indexOf(name) < 0;
      const opt = document.createElement('div');
      opt.className = 'dest-opt' + (state.dest.steel === name ? ' on' : '') + (disabled ? ' disabled' : '');
      opt.textContent = name;
      if (disabled) {
        opt.title = '该客户在客户库中状态异常（停用/待审核/已驳回），不可选用';
      } else {
        opt.title = '选填：作为末端收货钢厂';
        opt.addEventListener('click', () => {
          state.dest.steel = state.dest.steel === name ? '' : name; // 支持取消选择
          renderDest();
          refreshCoreSummary();
          refreshPlans();
        });
      }
      els.destSteels.appendChild(opt);
    });
  }

  function renderDestPath() {
    const ev = D.evalDestination(state.dest);
    if (!ev.path) {
      els.destPath.innerHTML = '未选择';
      return;
    }
    // 路径回显：站点（自动带出标注）/ 堆场 / 钢厂
    const parts = [];
    if (ev.station) {
      parts.push(esc(ev.station) + (state.dest.auto ? '<span class="auto-tag">自动带出</span>' : ''));
    }
    if (ev.yard) parts.push(esc(ev.yard));
    if (ev.steel) parts.push(esc(ev.steel));
    els.destPath.innerHTML = parts.join(' / ');
  }

  function renderDest() {
    renderDestStations();
    renderDestYards();
    renderDestSteels();
    renderDestPath();
  }

  function initDest() {
    try { state.customers = (window.HZCustomerData && window.HZCustomerData.loadStore()) || []; }
    catch (e) { state.customers = []; }
    els.destClear.addEventListener('click', () => {
      state.dest = { station: '', yard: '', steel: '', auto: false };
      clearHint('destination');
      renderDest();
      refreshCoreSummary();
      refreshPlans();
    });
    renderDest();
  }

  // 目的地实时提示：仅选站点未至堆场时给出引导（E5 完整校验在提交时执行）
  function validateDestLive() {
    const ev = D.evalDestination(state.dest);
    if (ev.level === 1) {
      showHint('destination', '请继续选择堆场（目的地需选至堆场）', 'warn');
    } else {
      clearHint('destination');
    }
  }

  /* ==================== 智能方案（F4 / A7 / E6 / E7） ==================== */

  let planTimer = null;
  // A7 自动刷新：相关输入变化后自动重算（轻微防抖，无按钮）
  function scheduleRefreshPlans() {
    clearTimeout(planTimer);
    planTimer = setTimeout(refreshPlans, 150);
  }

  function refreshPlans() {
    let res;
    try {
      res = D.computeSmartPlans(collectCore());
      els.planFail.hidden = true;
      state.planError = false;
    } catch (e) {
      // E6：生成失败，展示重试入口
      state.planError = true;
      state.plansRes = null;
      els.planGrid.hidden = true;
      els.planGrid.innerHTML = '';
      els.planStatus.hidden = true;
      els.planFail.hidden = false;
      els.sumPlan.textContent = '生成失败';
      return;
    }
    state.plansRes = res;
    renderPlans(res);
  }

  function renderPlans(res) {
    els.planFail.hidden = true;
    els.planStatus.hidden = false;
    if (!res.triggered) {
      els.planGrid.hidden = true;
      els.planGrid.innerHTML = '';
      els.planStatus.className = 'plan-status';
      els.planStatus.textContent = '补全「' + res.missing.join('、') + '」后自动生成运输方案';
      els.sumPlan.textContent = '待触发';
      return;
    }
    els.planStatus.className = 'plan-status ok';
    els.planStatus.textContent = '已自动生成 3 套方案（' + res.line + '）· 随输入自动刷新 · ' + res.computed_at;
    els.planGrid.hidden = false;
    els.planGrid.innerHTML = res.plans.map(planCardHtml).join('');
    els.sumPlan.textContent = '已生成';
  }

  function planCardHtml(p) {
    return '<div class="plan-card">' +
      '<div class="plan-card-head"><span class="plan-label">' + esc(p.label) + '</span>' +
      (p.tag ? '<span class="plan-tag">' + esc(p.tag) + '</span>' : '') +
      '</div>' +
      '<div class="plan-qty">' + esc(p.qty) + '<span class="plan-unit">' + esc(p.unit) + '</span></div>' +
      '<div class="plan-path">' + esc(p.path) + '</div>' +
      '<div class="plan-basis">' + esc(p.basis) + '</div>' +
      '<div class="plan-detail">' + esc(p.detail) + '</div>' +
      '</div>';
  }

  /* ==================== 取值与摘要 ==================== */

  function collectCore() {
    return {
      mine: els.mine.value.trim(),
      cargoName: els.cargoName.value.trim(),
      cargoQuality: els.cargoQuality.value.trim(),
      tonnage: els.tonnage.value.trim(),
      price: els.price.value.trim(),
      port: els.port.value.trim(),
      destination: { station: state.dest.station, yard: state.dest.yard, steel: state.dest.steel },
    };
  }

  function refreshCoreSummary() {
    const core = collectCore();
    const ev = D.evalDestination(core.destination);
    const bits = [];
    if (core.mine) bits.push(core.mine);
    if (core.port) bits.push(core.port);
    if (core.tonnage) bits.push(D.fmtNum(core.tonnage) + ' 吨');
    if (ev.path) bits.push('→ ' + ev.path);
    els.sumCore.textContent = bits.length ? bits.join(' · ') : '未填写';
    validateDestLive();
  }

  /* ==================== 校验（blur 即时 + 提交全量） ==================== */

  function initBlurValidation() {
    els.tonnage.addEventListener('blur', () => {
      showHint('tonnage', D.validateTonnage(els.tonnage.value.trim()), 'err');
      refreshCoreSummary();
    });
    els.price.addEventListener('blur', () => {
      showHint('price', D.validatePrice(els.price.value.trim()), 'err');
    });
    els.tonnage.addEventListener('input', scheduleRefreshPlans);
    els.mine.addEventListener('input', scheduleRefreshPlans);
    els.port.addEventListener('input', scheduleRefreshPlans);
  }

  // 提交全量校验：按 BR-O03 字段顺序定位首个错误并滚动聚焦
  function renderFormErrors(res) {
    ['mine', 'cargoName', 'cargoQuality', 'tonnage', 'price', 'port', 'destination'].forEach(f => {
      const msg = res.errors[f] || '';
      if (msg) showHint(f, msg, 'err');
      else if (f !== 'mine' && f !== 'port') clearHint(f);
    });
  }

  function focusFirstError(field) {
    if (field === '_subject') {
      els.banner.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (field === 'destination') {
      $('dest-cascade').scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    const input = FIELD_INPUT[field];
    if (input) {
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      try { input.focus(); } catch (e) { /* readonly 等不可聚焦场景忽略 */ }
    }
  }

  /* ==================== 提交（F6 / TBD-08 / TBD-10 / E8 / E9） ==================== */

  function collectPayload() {
    return {
      mine: els.mine.value.trim(),
      category: els.category.value.trim(),
      cargoName: els.cargoName.value.trim(),
      cargoQuality: els.cargoQuality.value.trim(),
      tonnage: els.tonnage.value.trim(),
      price: els.price.value.trim(),
      port: els.port.value.trim(),
      arrivalAt: els.arrivalAt.value,
      departAt: els.departAt.value,
      wharfs: state.wharfs.slice(),
      vessel: els.vessel.value.trim(),
      destination: { station: state.dest.station, yard: state.dest.yard, steel: state.dest.steel },
      vesselInfo: {
        company: $('v-company').value,
        scale: $('v-scale').value,
        type: els.vesselType.value,
        route: $('v-route').value,
        runTime: $('v-runTime').value,
        seaPrice: $('v-seaPrice').value,
        cycleTime: $('v-cycleTime').value,
        shipper: $('v-shipper').value,
        consignee: $('v-consignee').value,
      },
      plans: state.plansRes || { triggered: false, missing: [], plans: [] },
    };
  }

  function submitOrder() {
    if (state.submitting) return; // E8 防重：提交期间忽略重复点击
    const payload = collectPayload();
    const res = D.validateForm(payload, state.subjectRes);
    renderFormErrors(res);
    if (!res.ok) {
      focusFirstError(res.firstField);
      toast('请先完善表单必填项', 'error');
      return;
    }
    state.submitting = true;
    try {
      // 组装 flow 订单：提交即进入「待港口」状态（F6①，TBD-10 新页替代第 1 步）
      const order = D.buildOrder(payload, state.subjectRes);
      order.id = data.genOrderId();
      order.status = 'port';
      const nowIso = new Date().toISOString();
      order.createdAt = nowIso;
      order.updatedAt = nowIso;
      // 落库并联动：订单台账（达同步点时）+ 海运航次（船名与吨数齐备时，vessel_info 9 项随单同步）
      data.saveOrder(order);
      // 港口信息预填（F6③/TBD-10：港口名/码头首项带入，拥堵度默认正常）
      data.upsertPort(D.buildPortPrefill(order));
      // 运力方案预填（F6③/TBD-10：按智能方案生成 3 行通道，数值留 0 人工确认）
      data.upsertCapacities(order.id, D.buildCapacityPrefills(order, state.plansRes, data.genCapacityId));
      state.savedOrder = order; // 成功浮层跳转（进入港口信息 / 订单详情）携带订单 id
      // 提交成功浮层（TBD-08：进入下一步为主操作）
      els.successOrderId.textContent = order.id;
      els.successMask.hidden = false;
    } catch (e) {
      // E9：保存失败保留表单，提示重试
      toast('保存失败，请重试', 'error');
    } finally {
      state.submitting = false;
    }
  }

  /* ==================== 重置 ==================== */

  function resetForm() {
    els.mine.value = '';
    els.category.value = '';
    els.cargoName.value = '';
    els.cargoQuality.value = '';
    els.tonnage.value = '';
    els.price.value = '';
    els.port.value = '';
    els.arrivalAt.value = '';
    els.departAt.value = '';
    els.vessel.value = '';
    state.wharfs = [];
    els.wharfChips.querySelectorAll('.chip').forEach(c => c.classList.remove('on'));
    ['mine', 'category', 'cargoName', 'cargoQuality', 'tonnage', 'price', 'port', 'destination']
      .forEach(clearHint);
    state.dest = { station: '', yard: '', steel: '', auto: false };
    ['v-company', 'v-scale', 'v-route', 'v-runTime', 'v-seaPrice', 'v-cycleTime', 'v-shipper', 'v-consignee']
      .forEach(id => { $(id).value = ''; });
    els.vesselType.value = '';
    renderDest();
    refreshCoreSummary();
    refreshPlans();
    toast('已重置');
  }

  /* ==================== 事件绑定与启动 ==================== */

  function bindEvents() {
    document.querySelectorAll('[data-collapse]').forEach(head => {
      head.addEventListener('click', () => {
        head.closest('.flow-collapse').classList.toggle('open');
      });
    });
    els.planRetry.addEventListener('click', refreshPlans); // E6 重试
    els.btnSubmit.addEventListener('click', submitOrder);
    els.btnReset.addEventListener('click', resetForm);
    els.btnGoPort.addEventListener('click', () => {
      location.href = '/business/flow/order-port.html?id=' + encodeURIComponent(state.savedOrder ? state.savedOrder.id : '');
    });
    els.btnGoDetail.addEventListener('click', () => {
      location.href = '/business/flow/order-detail.html?id=' + encodeURIComponent(state.savedOrder ? state.savedOrder.id : '');
    });
    els.destStations.addEventListener('click', e => {
      if (e.target.classList.contains('dest-opt')) validateDestLive();
    });
  }

  function init() {
    initSubject();       // F2：自然信息自动填充（含 E1 阻断 / TBD-01 降级提示）
    initMineOptions();
    initPortOptions();
    initWharfChips();
    initVesselType();
    initMineSS();
    initPortSS();
    initDest();          // G4：目的地三级级联（含 BR-O11 客户库联动）
    initBlurValidation();
    bindEvents();
    refreshCoreSummary();
    refreshPlans();      // F4：初始未触发，展示缺失项提示
  }

  init();
})();
